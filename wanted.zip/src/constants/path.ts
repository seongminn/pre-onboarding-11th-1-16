export const PATH = {
  MAIN: '/',
  TODO: '/todo',
  SIGNUP: '/signup',
  SIGNIN: '/signin',
};
