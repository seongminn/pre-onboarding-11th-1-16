export const TOKEN_KEY = 'user-token';
